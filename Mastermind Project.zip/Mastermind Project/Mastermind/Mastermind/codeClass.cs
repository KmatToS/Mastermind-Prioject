﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mastermind
{
    class codeClass
    {
        string firstPeg;
        string secondPeg;
        string thirdPeg;
        string fourthPeg;
        Random rng = new Random();
        string[] colorArray = new string[6] {"Red", "Blue", "Yellow", "Green", "Purple", "Orange"};

        public codeClass()
        {//constructor that makes a random code for the solution
            firstPeg = randomColor();
            secondPeg = randomColor();
            thirdPeg = randomColor();
            fourthPeg = randomColor();
        }
        public codeClass(string first, string second, string third, string fourth)
        {//constructor that uses strings with Color from the guess
            firstPeg = first;
            secondPeg = second;
            thirdPeg = third;
            fourthPeg = fourth;
        }

        //get methods for each object's pegs
        public string getFirstPeg()
        {
            return firstPeg;
        }
        public string getSecondPeg()
        {
            return secondPeg;
        }
        public string getThirdPeg()
        {
            return thirdPeg;
        }
        public string getFourthPeg()
        {
            return fourthPeg;
        }

        //end get methods

        private string randomColor()
        {//returns a random color string from one of the six listed in colorArray
            int colorNum = rng.Next(1, 6);
            string randColor = colorArray[(colorNum - 1)];
            return randColor;
        }
    }//end class
}//end namespace
