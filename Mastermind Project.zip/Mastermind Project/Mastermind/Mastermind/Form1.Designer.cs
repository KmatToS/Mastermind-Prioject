﻿namespace Mastermind
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstBox = new System.Windows.Forms.ComboBox();
            this.fourthBox = new System.Windows.Forms.ComboBox();
            this.thirdBox = new System.Windows.Forms.ComboBox();
            this.secondBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnRules = new System.Windows.Forms.Button();
            this.btnCheat = new System.Windows.Forms.Button();
            this.lblGuessCount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // firstBox
            // 
            this.firstBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.firstBox.FormattingEnabled = true;
            this.firstBox.Items.AddRange(new object[] {
            "Red",
            "Blue",
            "Yellow",
            "Green",
            "Purple",
            "Orange"});
            this.firstBox.Location = new System.Drawing.Point(15, 65);
            this.firstBox.MaxDropDownItems = 6;
            this.firstBox.Name = "firstBox";
            this.firstBox.Size = new System.Drawing.Size(75, 21);
            this.firstBox.TabIndex = 0;
            // 
            // fourthBox
            // 
            this.fourthBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.fourthBox.FormattingEnabled = true;
            this.fourthBox.Items.AddRange(new object[] {
            "Red",
            "Blue",
            "Yellow",
            "Green",
            "Purple",
            "Orange"});
            this.fourthBox.Location = new System.Drawing.Point(366, 65);
            this.fourthBox.MaxDropDownItems = 6;
            this.fourthBox.Name = "fourthBox";
            this.fourthBox.Size = new System.Drawing.Size(75, 21);
            this.fourthBox.TabIndex = 1;
            // 
            // thirdBox
            // 
            this.thirdBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.thirdBox.FormattingEnabled = true;
            this.thirdBox.Items.AddRange(new object[] {
            "Red",
            "Blue",
            "Yellow",
            "Green",
            "Purple",
            "Orange"});
            this.thirdBox.Location = new System.Drawing.Point(249, 65);
            this.thirdBox.MaxDropDownItems = 6;
            this.thirdBox.Name = "thirdBox";
            this.thirdBox.Size = new System.Drawing.Size(75, 21);
            this.thirdBox.TabIndex = 2;
            // 
            // secondBox
            // 
            this.secondBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.secondBox.FormattingEnabled = true;
            this.secondBox.Items.AddRange(new object[] {
            "Red",
            "Blue",
            "Yellow",
            "Green",
            "Purple",
            "Orange"});
            this.secondBox.Location = new System.Drawing.Point(132, 65);
            this.secondBox.MaxDropDownItems = 6;
            this.secondBox.Name = "secondBox";
            this.secondBox.Size = new System.Drawing.Size(75, 21);
            this.secondBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(431, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Choose the four colors (in order) that you wish to submit as your guess, then pre" +
    "ss Confirm.";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(15, 129);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(75, 23);
            this.btnConfirm.TabIndex = 5;
            this.btnConfirm.Text = "&Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(366, 129);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnRules
            // 
            this.btnRules.Location = new System.Drawing.Point(249, 129);
            this.btnRules.Name = "btnRules";
            this.btnRules.Size = new System.Drawing.Size(75, 23);
            this.btnRules.TabIndex = 7;
            this.btnRules.Text = "&Rules";
            this.btnRules.UseVisualStyleBackColor = true;
            this.btnRules.Click += new System.EventHandler(this.btnRules_Click);
            // 
            // btnCheat
            // 
            this.btnCheat.Location = new System.Drawing.Point(132, 129);
            this.btnCheat.Name = "btnCheat";
            this.btnCheat.Size = new System.Drawing.Size(75, 23);
            this.btnCheat.TabIndex = 8;
            this.btnCheat.Text = "Ch&eat";
            this.btnCheat.UseVisualStyleBackColor = true;
            this.btnCheat.Click += new System.EventHandler(this.btnCheat_Click);
            // 
            // lblGuessCount
            // 
            this.lblGuessCount.AutoSize = true;
            this.lblGuessCount.Location = new System.Drawing.Point(12, 33);
            this.lblGuessCount.Name = "lblGuessCount";
            this.lblGuessCount.Size = new System.Drawing.Size(161, 13);
            this.lblGuessCount.TabIndex = 9;
            this.lblGuessCount.Text = "You have 10 guesses remaining.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 164);
            this.Controls.Add(this.lblGuessCount);
            this.Controls.Add(this.btnCheat);
            this.Controls.Add(this.btnRules);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.secondBox);
            this.Controls.Add(this.thirdBox);
            this.Controls.Add(this.fourthBox);
            this.Controls.Add(this.firstBox);
            this.Name = "Form1";
            this.Text = "Mastermind";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox firstBox;
        private System.Windows.Forms.ComboBox fourthBox;
        private System.Windows.Forms.ComboBox thirdBox;
        private System.Windows.Forms.ComboBox secondBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRules;
        private System.Windows.Forms.Button btnCheat;
        private System.Windows.Forms.Label lblGuessCount;
    }
}

